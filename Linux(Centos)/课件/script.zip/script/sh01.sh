#!/bin/bash
# Program:
# This program shows "Hello World!" in your screen.
# History:
# 2018/08/23	Bobby	First release
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
echo -e "Hello World! \a \n"
exit 0

